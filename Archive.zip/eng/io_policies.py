# eng/io_policies.py
import numpy as np

from eng.policies import LinearPolicy
from eng.policies_mlp import MLPPolicy


# ---------- SAVE ----------
def save_policy_npz(policy, path: str):
    """
    Unified saver for LinearPolicy and MLPPolicy.
    Relies on policy.as_dict() (both classes implement it).
    """
    d = policy.as_dict()
    # keep arrays as-is; include 'kind'
    if "kind" not in d:
        # try to infer (shouldn't happen with our classes)
        d["kind"] = "linear" if isinstance(policy, LinearPolicy) else "mlp"
    np.savez_compressed(path, **d)


# ---------- LOAD ----------
def load_policy_npz(path: str):
    """
    Load either linear or mlp policy from a .npz created by save_policy_npz().
    Accepts both ['kind'='linear'|'mlp'] and heuristic formats (W,b or W0/b0...).
    Returns a policy object with .forward/__call__/mutate/clone.
    """
    data = np.load(path, allow_pickle=True)
    files = set(data.files)
    kind = None

    if "kind" in files:
        # stored as object or string
        k = data["kind"]
        kind = k.item() if hasattr(k, "item") else str(k)

    # ---- Linear: W, b ----
    if kind == "linear" or {"W", "b"}.issubset(files):
        W, b = data["W"], data["b"]
        return LinearPolicy(W, b)

    # ---- MLP: W0/b0, W1/b1, ... ----
    if kind == "mlp" or any(name.startswith("W") for name in files):
        # collect in order
        layers = []
        i = 0
        while f"W{i}" in data.files:
            Wi = data[f"W{i}"]
            bi = data[f"b{i}"] if f"b{i}" in data.files else np.zeros((Wi.shape[0],), dtype=Wi.dtype)
            layers.append((Wi, bi))
            i += 1
        if not layers:
            raise ValueError(f"No MLP layers found in {path} (looked for W0/b0...).")
        return MLPPolicy(layers=layers)

    # ---- Heuristic fallback: raw arrays with shapes ----
    if {"W", "b"}.intersection(files):
        W = data.get("W", None)
        b = data.get("b", None)
        # decide based on dimensionality
        if W is not None and b is not None and W.ndim == 2 and b.ndim == 1:
            return LinearPolicy(W, b)

    raise ValueError(f"Unrecognized policy format in {path}; keys={sorted(files)}")